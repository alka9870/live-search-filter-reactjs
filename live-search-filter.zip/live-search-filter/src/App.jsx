import React from "react";
import Search from "./Search";
const App = () =>{
    return(
        <>
          <Search/>
        </>
    );
};

export default App;