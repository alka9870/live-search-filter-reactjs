import React from "react";


const Sresult = (props) =>{
    const img = `https://source.unsplash.com/random/720x700/?${props.name}`;
    return (
        <>
            <div>
                <img src={img} alt="AlkaImgSearch"/>
            </div>
        </>
    );
};

export default Sresult;
